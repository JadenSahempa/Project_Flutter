class AppConfig {
  static const apiBaseUrl = 'https://ls-lms.zoidify.my.id';
  static const defaultToken = 'default-token-dev-atau-staging';
}
