// import 'package:firebase_auth/firebase_auth.dart';
// import 'package:luar_sekolah_lms/week_9/domain/entities/auth_user.dart';

// class UserModel extends UserEntity {
//   UserModel({required super.uid, super.email});

//   factory UserModel.fromFirebaseUser(User user) {
//     return UserModel(uid: user.uid, email: user.email);
//   }
// }
