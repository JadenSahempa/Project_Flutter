// import 'package:get/get.dart';

// import 'presentation/admin/screens/kelas_terpopuler_screens.dart'
// import 'presentation/screens/course_list_screen.dart';
// import 'presentation/admin/screens/course_add_screens.dart';
// import 'presentation/admin/screens/course_edit_screens.dart';
// import 'course_bindings.dart';

// class CourseRoutes {
//   static const list = '/course-list';
//   static const add = '/course-add';
//   static const edit = '/course-edit';
// }

// final coursePages = [
//   GetPage(
//     name: CourseRoutes.list,
//     page: () => const CourseListScreen(),
//     binding: CourseBindings(),
//   ),
//   GetPage(
//     name: CourseRoutes.add,
//     page: () => const CourseAddScreen(),
//     binding: CourseBindings(),
//   ),
//   GetPage(
//     name: CourseRoutes.edit,
//     page: () => CourseEditScreen(courseId: Get.arguments),
//     binding: CourseBindings(),
//   ),
// ];
